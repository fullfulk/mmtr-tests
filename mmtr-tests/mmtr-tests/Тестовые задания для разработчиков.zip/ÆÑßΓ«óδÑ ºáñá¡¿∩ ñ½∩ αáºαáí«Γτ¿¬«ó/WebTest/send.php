<?php
if (isset($_POST['name'], $_POST['color'], $_POST['18-years'], $_POST['radio-morning'], $_POST['radio-night'])) {
    echo ('data is' . $_POST['name']);
}